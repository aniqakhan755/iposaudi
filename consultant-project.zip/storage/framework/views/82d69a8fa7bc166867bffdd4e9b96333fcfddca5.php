<?php $__env->startSection('content'); ?>
    <ul class="breadcrumb">

        <li class="breadcrumb-item">
            <a href="<?php echo e(route('home')); ?>">Dashboard</a>
        </li>
    </ul>

    <div class="content-i">
        <div class="content-box" >
            <div class="row">
                <div class="col-sm-12">
                    <div class="element-wrapper">
                        <h6 class="element-header">
                            Manage Services
                        </h6>
                        <form action="<?php echo e(route('services.post')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                        <div class="element-content">
                            <div class="row">
                                <div class="col-12">
                                    <div class="element-box">

                                        <fieldset class="form-group">
                                            <legend><span>Service 1</span></legend>
                                            <div class="row">
                                                <div class="col-sm-12">
                                                    <div class="form-group">
                                                        <label for="">Title <span class="color-red">*</span></label>
                                                        <input class="form-control" placeholder="Title" required  value="<?php echo e($service_configuration->service_title_1); ?>" type="text" name="service_title_1" >
                                                    </div>
                                                </div>
                                                <div class="col-sm-12">
                                                    <div class="form-group">
                                                        <label for="">Service Description <span class="color-red">*</span></label>
                                                        <textarea class="form-control" placeholder="Description"  required   type="text" rows="4" name="service_desc_1"><?php echo e($service_configuration->service_desc_1); ?></textarea>
                                                    </div>
                                                </div>
                                            </div>
                                        </fieldset>
                                        <fieldset class="form-group">
                                            <legend><span>Service 2</span></legend>
                                            <div class="row">
                                                <div class="col-sm-12">
                                                    <div class="form-group">
                                                        <label for="">Title <span class="color-red">*</span></label>
                                                        <input class="form-control" placeholder="Title" required type="text" value="<?php echo e($service_configuration->service_title_2); ?>"  name="service_title_2">
                                                    </div>
                                                </div>
                                                <div class="col-sm-12">
                                                    <div class="form-group">
                                                        <label for="">Service Description <span class="color-red">*</span></label>
                                                        <textarea class="form-control" placeholder="Description" required type="text"   rows="4" name="service_desc_2"><?php echo e($service_configuration->service_desc_2); ?></textarea>
                                                    </div>
                                                </div>
                                            </div>
                                        </fieldset>
                                        <fieldset class="form-group">
                                            <legend><span>Service 3</span></legend>
                                            <div class="row">
                                                <div class="col-sm-12">
                                                    <div class="form-group">
                                                        <label for="">Title <span class="color-red">*</span></label>
                                                        <input class="form-control" placeholder="Title" required type="text" name="service_title_3" value="<?php echo e($service_configuration->service_title_3); ?>">
                                                    </div>
                                                </div>
                                                <div class="col-sm-12">
                                                    <div class="form-group">
                                                        <label for="">Service Description <span class="color-red">*</span></label>
                                                        <textarea class="form-control" placeholder="Description" required type="text" rows="4" name="service_desc_3"><?php echo e($service_configuration->service_desc_3); ?></textarea>
                                                    </div>
                                                </div>
                                            </div>
                                        </fieldset>
                                        <fieldset class="form-group">
                                            <legend><span>Service 4</span></legend>
                                            <div class="row">
                                                <div class="col-sm-12">
                                                    <div class="form-group">
                                                        <label for="">Title <span class="color-red">*</span></label>
                                                        <input class="form-control" placeholder="Title" required type="text" value="<?php echo e($service_configuration->service_title_4); ?>" name="service_title_4">
                                                    </div>
                                                </div>
                                                <div class="col-sm-12">
                                                    <div class="form-group">
                                                        <label for="">Service Description <span class="color-red">*</span></label>
                                                        <textarea class="form-control" placeholder="Description" required type="text" rows="4" name="service_desc_4"><?php echo e($service_configuration->service_desc_4); ?></textarea>
                                                    </div>
                                                </div>
                                            </div>
                                        </fieldset>
                                        <fieldset class="form-group">
                                            <legend><span>Service 5</span></legend>
                                            <div class="row">
                                                <div class="col-sm-12">
                                                    <div class="form-group">
                                                        <label for="">Title <span class="color-red">*</span></label>
                                                        <input class="form-control" placeholder="Title" required type="text" value="<?php echo e($service_configuration->service_title_5); ?>" name="service_title_5">
                                                    </div>
                                                </div>
                                                <div class="col-sm-12">
                                                    <div class="form-group">
                                                        <label for="">Service Description <span class="color-red">*</span></label>
                                                        <textarea class="form-control" placeholder="Description" required type="text" rows="4" name="service_desc_5"><?php echo e($service_configuration->service_desc_5); ?></textarea>
                                                    </div>
                                                </div>
                                            </div>
                                        </fieldset>
                                        <fieldset class="form-group">
                                            <legend><span>Service 6</span></legend>
                                            <div class="row">
                                                <div class="col-sm-12">
                                                    <div class="form-group">
                                                        <label for="">Title <span class="color-red">*</span></label>
                                                        <input class="form-control" placeholder="Title" type="text" required value="<?php echo e($service_configuration->service_title_6); ?>" name="service_title_6">
                                                    </div>
                                                </div>
                                                <div class="col-sm-12">
                                                    <div class="form-group">
                                                        <label for="">Service Description <span class="color-red">*</span></label>
                                                        <textarea class="form-control" placeholder="Description" type="text" required rows="4" name="service_desc_6"><?php echo e($service_configuration->service_desc_6); ?></textarea>
                                                    </div>
                                                </div>
                                            </div>
                                        </fieldset>
                                        <fieldset class="form-group">
                                            <legend><span>Service 7</span></legend>
                                            <div class="row">
                                                <div class="col-sm-12">
                                                    <div class="form-group">
                                                        <label for="">Title <span class="color-red">*</span></label>
                                                        <input class="form-control" placeholder="Title" required value="<?php echo e($service_configuration->service_title_7); ?>" type="text" name="service_title_7">
                                                    </div>
                                                </div>
                                                <div class="col-sm-12">
                                                    <div class="form-group">
                                                        <label for="">Service Description <span class="color-red">*</span></label>
                                                        <textarea class="form-control" placeholder="Description"required type="text" rows="4" name="service_desc_7"><?php echo e($service_configuration->service_desc_7); ?></textarea>
                                                    </div>
                                                </div>
                                            </div>
                                        </fieldset>
                                        <fieldset class="form-group">
                                            <legend><span>Service 8</span></legend>
                                            <div class="row">
                                                <div class="col-sm-12">
                                                    <div class="form-group">
                                                        <label for="">Title <span class="color-red">*</span></label>
                                                        <input class="form-control" placeholder="Title" required value="<?php echo e($service_configuration->service_title_8); ?>" type="text" name="service_title_8">
                                                    </div>
                                                </div>
                                                <div class="col-sm-12">
                                                    <div class="form-group">
                                                        <label for="">Service Description <span class="color-red">*</span></label>
                                                        <textarea class="form-control" placeholder="Description" required type="text" rows="4" name="service_desc_8"><?php echo e($service_configuration->service_desc_8); ?></textarea>
                                                    </div>
                                                </div>
                                            </div>
                                        </fieldset>



                                        <div class="form-buttons-w">
                                            <button class="btn btn-primary" type="submit"> Submit</button>
                                        </div>


                                    </div>

                                </div>


                            </div>
                        </div>
                        </form>
                    </div>
                </div>
            </div>


        </div>
    </div>

    <div class="display-type"></div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\consultant-project\resources\views/manage-services.blade.php ENDPATH**/ ?>