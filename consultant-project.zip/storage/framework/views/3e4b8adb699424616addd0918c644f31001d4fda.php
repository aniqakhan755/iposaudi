<!DOCTYPE html>
<html>
<head>
    <title>IPO Saudi</title>
    <meta charset="utf-8">
    <meta content="ie=edge" http-equiv="x-ua-compatible">
    <meta content="template language" name="keywords">
    <meta content="Tamerlan Soziev" name="author">
    <meta content="Admin dashboard html template" name="description">
    <meta content="width=device-width, initial-scale=1" name="viewport">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link href="favicon.png" rel="shortcut icon">
    <link href="apple-touch-icon.png" rel="apple-touch-icon">

    <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('icon_fonts_assets/font-awesome/css/font-awesome.min.css')); ?>" async defer>
    <link href="<?php echo e(asset('bower_components/select2/dist/css/select2.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('bower_components/bootstrap-daterangepicker/daterangepicker.css')); ?>" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.10.22/css/dataTables.bootstrap4.min.css" rel="stylesheet">
    <link href="<?php echo e(asset('bower_components/fullcalendar/dist/fullcalendar.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('bower_components/perfect-scrollbar/css/perfect-scrollbar.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('bower_components/slick-carousel/slick/slick.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/pretty.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/main.css?version=4.5.0')); ?>" rel="stylesheet">
     <link href="<?php echo e(asset('css/custom.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/custom-dashboard-style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('bower_components/toastr/toastr.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('bower_components/dropify/dropify.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('bower_components/dropzone/dropzone.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('icon_fonts_assets/feather/style.css')); ?>" rel="stylesheet">
    <?php echo $__env->yieldContent('styles'); ?>
</head>
<body class="menu-position-side menu-side-left full-screen">
    <div class="all-wrapper with-side-panel solid-bg-all">
        <div class="layout-w">
            <?php echo $__env->make('components.includes.mobile-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('components.includes.side-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="content-w">
                <?php echo $__env->make('components.includes.top-bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>
    </div>
    <script src="<?php echo e(asset('bower_components/jquery/dist/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('bower_components/popper.js/dist/umd/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('bower_components/moment/moment.js')); ?>"></script>
    <script src="<?php echo e(asset('bower_components/chart.js/dist/Chart.min.js')); ?>"></script>
    <script src="<?php echo e(asset('bower_components/select2/dist/js/select2.full.min.js')); ?>"></script>
    <script src="<?php echo e(asset('bower_components/jquery-bar-rating/dist/jquery.barrating.min.js')); ?>"></script>
    <script src="<?php echo e(asset('bower_components/ckeditor/ckeditor.js')); ?>"></script>
    <script src="<?php echo e(asset('bower_components/bootstrap-validator/dist/validator.min.js')); ?>"></script>
    <script src="<?php echo e(asset('bower_components/bootstrap-daterangepicker/daterangepicker.js')); ?>"></script>
    <script src="<?php echo e(asset('bower_components/ion.rangeSlider/js/ion.rangeSlider.min.js')); ?>"></script>
    <script src="<?php echo e(asset('bower_components/editable-table/mindmup-editabletable.js')); ?>"></script>
    <script src="<?php echo e(asset('bower_components/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('bower_components/fullcalendar/dist/fullcalendar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('bower_components/perfect-scrollbar/js/perfect-scrollbar.jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('bower_components/tether/dist/js/tether.min.js')); ?>"></script>
    <script src="<?php echo e(asset('bower_components/slick-carousel/slick/slick.min.js')); ?>"></script>
    <script src="<?php echo e(asset('bower_components/bootstrap/js/dist/util.js')); ?>"></script>
    <script src="<?php echo e(asset('bower_components/bootstrap/js/dist/alert.js')); ?>"></script>
    <script src="<?php echo e(asset('bower_components/bootstrap/js/dist/button.js')); ?>"></script>
    <script src="<?php echo e(asset('bower_components/bootstrap/js/dist/carousel.js')); ?>"></script>
    <script src="<?php echo e(asset('bower_components/bootstrap/js/dist/collapse.js')); ?>"></script>
    <script src="<?php echo e(asset('bower_components/bootstrap/js/dist/dropdown.js')); ?>"></script>
    <script src="<?php echo e(asset('bower_components/bootstrap/js/dist/modal.js')); ?>"></script>
    <script src="<?php echo e(asset('bower_components/bootstrap/js/dist/tab.js')); ?>"></script>
    <script src="<?php echo e(asset('bower_components/bootstrap/js/dist/tooltip.js')); ?>"></script>
    <script src="<?php echo e(asset('bower_components/bootstrap/js/dist/popover.js')); ?>"></script>
    <script src="<?php echo e(asset('js/demo_customizer.js?version=4.5.0')); ?>"></script>
    <script src="<?php echo e(asset('js/main.js?version=4.5.0')); ?>"></script>
    
    <script src="<?php echo e(asset('bower_components/toastr/toastr.min.js')); ?>"></script>
    <script src="<?php echo e(asset('bower_components/sweetalert/sweetalert.min.js')); ?>"></script>
    <script src="<?php echo e(asset('bower_components/dropify/dropify.min.js')); ?>"></script>
    <script src="<?php echo e(asset('bower_components/dropzone/dropzone.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/custom/form.js')); ?>"></script>
    <script>
        Dropzone.autoDiscover = false;
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        function resetDropify(file = "") {
            drEvent = $('.dropify').data('dropify');
            drEvent.resetPreview();
            drEvent.clearElement();
            drEvent.settings.defaultFile = file;
            drEvent.destroy();
            drEvent.init();
        }

        $(document).ready(function() {
            $('.btn-delete').on('click', function(e) {
                var deleteButton =$(this);

                e.preventDefault();

                swal({
                    title: 'Are you sure?',
                    text: 'This record and it`s details will be permanantly deleted!',
                    icon: 'warning',
                    buttons: ["Cancel", "Yes!"],
                }).then(function(value) {
                    if (value) {
                        deleteButton.parent('form').submit();
                    }
                });
            });
            toastr.options = {
                "closeButton": false,
                "debug": false,
                "newestOnTop": true,
                "positionClass": "toast-bottom-right",
                "preventDuplicates": false,
                "onclick": null,
                "showDuration": "300",
                "hideDuration": "1500",
                "timeOut": "5000",
                "extendedTimeOut": "1500",
                "showEasing": "swing",
                "hideEasing": "linear",
                "showMethod": "fadeIn",
                "hideMethod": "fadeOut"
            }

            <?php if(count($errors) > 0): ?>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    toastr.error("<?php echo e($error); ?>");
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

            <?php if(Session::has('success')): ?>
                toastr.success("<?php echo e(Session::get('success')); ?>");
            <?php endif; ?>

            <?php if(Session::has('info')): ?>
                toastr.info("<?php echo e(Session::get('info')); ?>");
            <?php endif; ?>

            <?php if(Session::has('warning')): ?>
                toastr.warning("<?php echo e(Session::get('warning')); ?>");
            <?php endif; ?>

            $('.dropify').dropify();
        })
    </script>
     <?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\wamp64\www\consultant-project\resources\views/layouts/dashboard-template.blade.php ENDPATH**/ ?>