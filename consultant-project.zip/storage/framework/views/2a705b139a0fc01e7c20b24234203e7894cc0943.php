<div class="menu-mobile menu-activated-on-click color-scheme-dark">
    <div class="mm-logo-buttons-w">
        <a class="mm-logo" href="<?php echo e(route('home')); ?>"><img src="<?php echo e(asset('assets/images/logo-website.png')); ?>" alt="logo"></a>
        <div class="mm-buttons">
            <div class="content-panel-open">
                <div class="os-icon os-icon-grid-circles"></div>
            </div>
            <div class="mobile-menu-trigger">
                <div class="os-icon os-icon-hamburger-menu-1"></div>
            </div>
        </div>
    </div>
    <div class="menu-and-user">
        <!--------------------
        START - Mobile Menu List
        -------------------->
        <ul class="main-menu">
            <li>
                <a href="<?php echo e(route('home')); ?>">
                    <div class="icon-w">
                        <div class="os-icon os-icon-layout"></div>
                    </div>
                    <span>Dashboard</span></a>
            </li>
        </ul>
        <!--------------------
        END - Mobile Menu List
        -------------------->
    </div>
</div>
<?php /**PATH C:\wamp64\www\consultant-project\resources\views/components/includes/mobile-menu.blade.php ENDPATH**/ ?>