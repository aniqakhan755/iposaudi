<?php $__env->startSection('content'); ?>
    <ul class="breadcrumb">

        <li class="breadcrumb-item">
            <a href="<?php echo e(route('home')); ?>">Dashboard</a>
        </li>
    </ul>

    <div class="content-i">
        <div class="content-box">














































































        </div>
        <!--------------------
        START - Sidebar
        -------------------->
        <div class="content-panel">
            <div class="content-panel-close">
                <i class="os-icon os-icon-close"></i>
            </div>
            <div class="element-wrapper">
                <h6 class="element-header">
                    Quick Links
                </h6>
                <div class="element-box-tp">
                    <div class="el-buttons-list full-width">
                        <a class="btn btn-white btn-sm" href="<?php echo e(route('manage.sliders')); ?>"><span>Manage Sliders</span></a>
                        <a class="btn btn-white btn-sm" href="<?php echo e(route('manage.about')); ?>"><span>Manage About</span></a>
                        <a class="btn btn-white btn-sm" href="<?php echo e(route('manage.services')); ?>"><span>Manage Services</span></a>
                    </div>
                </div>
            </div>
        </div>
        <!--------------------
        END - Sidebar
        -------------------->
    </div>

    <div class="display-type"></div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\consultant-project\resources\views/dashboard.blade.php ENDPATH**/ ?>