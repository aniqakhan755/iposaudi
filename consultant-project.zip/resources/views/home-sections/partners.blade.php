<!-- Partner Section Start -->
<div class="rs-partner modify5 blue-bg pt-70 pb-55">

</div>
<!-- Partner Section End -->
