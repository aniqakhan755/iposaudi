<!-- Counter Section Start -->
<div class="rs-counter style1 shape-bg1 pt-105 md-pt-82 pb-97 md-pb-77">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-6 col-sm-6 md-mb-30">
                <div class="couter-part plus">
                    <div class="icon-part">
                        <img src="assets/images/counter/icon/1.png" alt="">
                    </div>
                    <div class="rs-count">500</div>
                    <h5 class="title">Project Completed</h5>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6 md-mb-30">
                <div class="couter-part plus">
                    <div class="icon-part">
                        <img src="assets/images/counter/icon/2.png" alt="">
                    </div>
                    <div class="rs-count">115</div>
                    <h5 class="title">HR Consultants</h5>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6 xs-mb-30">
                <div class="couter-part plus">
                    <div class="icon-part">
                        <img src="assets/images/counter/icon/3.png" alt="">
                    </div>
                    <div class="rs-count">100</div>
                    <h5 class="title">Awards WON</h5>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6">
                <div class="couter-part thousand">
                    <div class="icon-part">
                        <img src="assets/images/counter/icon/4.png" alt="">
                    </div>
                    <div class="rs-count">920</div>
                    <h5 class="title">Happy Clients</h5>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Counter Section End -->
